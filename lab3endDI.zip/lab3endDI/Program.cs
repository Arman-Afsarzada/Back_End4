﻿using System;
using System.Security.Cryptography;
using Microsoft.Extensions.DependencyInjection;

namespace lab3endDI
{
    class Program
    {
        static void Main(string[] args)
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddTransient<IMyService, MyService>();
            var serviceProvider = serviceCollection.BuildServiceProvider();
            var myService = serviceProvider.GetService<IMyService>();

            if (myService != null)
            {
                myService.PerformTask();

                Console.Write("What is Your name?");
                string? name = Console.ReadLine();
                if (!string.IsNullOrEmpty(name))
                {
                    string greeting = myService.GetGreeting(name);
                    Console.WriteLine(greeting);
                }
                else
                {
                    Console.WriteLine("Did not enter a name.");
                }

            }
            else
            {
                Console.WriteLine("Not succssesfuly resolved the service!");
            }
        }
    }
}