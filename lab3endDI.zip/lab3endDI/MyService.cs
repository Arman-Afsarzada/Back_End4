namespace lab3endDI
{
    public class MyService : IMyService
    {
        public void PerformTask()
        {
            Console.WriteLine("Performing a task using DI");
        }

        public string GetGreeting(string name)
        {
            return $"Hello {name}! \nWelcome to the DI (Dependency Injection) Console app";
        }
    }
}