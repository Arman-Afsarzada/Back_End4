namespace lab3endDI
{
    public interface IMyService
    {
        void PerformTask();
        string GetGreeting(string name);
    }
}