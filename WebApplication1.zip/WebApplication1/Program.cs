var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

app.UseStaticFiles(); // Serve static files like CSS, JS, images
app.UseRouting(); // Enable routing middleware
app.UseAuthorization(); // Enable authorization middleware

// Define custom routes for /page1, /page2, and /page3
app.MapControllerRoute(
    name: "custom",
    pattern: "{action=Page1}", // Default action is Page1
    defaults: new { controller = "Home" } // Default controller is Home
);

// Fallback route (optional): Redirects unknown routes to Home/Index
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}"
);

app.Run(); // Start the application