using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        // Action for /page1
        public ContentResult Page1()
        {
            return Content("Hello World from Page 1", "text/plain");
        }

        // Action for /page2
        public ContentResult Page2()
        {
            return Content("Hello World from Page 2", "text/plain");
        }

        // Action for /page3
        public ContentResult Page3()
        {
            return Content("Hello World from Page 3", "text/plain");
        }
    }
}